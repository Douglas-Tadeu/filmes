<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_---------  Netflix  Marvel</name>
   <tag></tag>
   <elementGuidId>7a20e6d9-306c-4423-b3cc-70306bedb2cb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#id_diretor</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='id_diretor']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:label=&quot;Diretor:&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>d7bdf6d8-78af-4782-b842-be8c274421ce</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>diretor</value>
      <webElementGuid>bca1986e-132d-4006-b671-07e57f045953</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>id_diretor</value>
      <webElementGuid>f425a097-2204-4f00-93e8-c9bbba306c5f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
  ---------

  Netflix

  Marvel

</value>
      <webElementGuid>beda9acc-494d-4dfb-be7d-5f428f7dad4d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;id_diretor&quot;)</value>
      <webElementGuid>9bb9b43d-1ec1-477f-a298-fbbc4708296b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='id_diretor']</value>
      <webElementGuid>55372313-3184-47f0-bfad-f1c98ac20729</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Diretor:'])[1]/following::select[1]</value>
      <webElementGuid>0e6f2c1e-3324-4321-8906-b18e513635af</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Genero:'])[1]/following::select[2]</value>
      <webElementGuid>ce569547-5e58-4186-aa34-91f51cb3a219</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Classificacao:'])[1]/preceding::select[1]</value>
      <webElementGuid>1a789f4c-b821-4d92-a371-f7bff7c362a3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Trailer:'])[1]/preceding::select[2]</value>
      <webElementGuid>9fb03d5a-8752-4e04-bd6b-b9fa6f3d9c27</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p[5]/select</value>
      <webElementGuid>19350122-d575-4877-a417-b04df136c7a2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@name = 'diretor' and @id = 'id_diretor' and (text() = '
  ---------

  Netflix

  Marvel

' or . = '
  ---------

  Netflix

  Marvel

')]</value>
      <webElementGuid>583d5acc-3ebd-4a5a-9f9e-01f0cee47d83</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
