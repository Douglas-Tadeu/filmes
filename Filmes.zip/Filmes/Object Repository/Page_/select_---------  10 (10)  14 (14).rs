<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_---------  10 (10)  14 (14)</name>
   <tag></tag>
   <elementGuidId>a12611ce-ebbf-45e3-828c-4f65bd547782</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#id_classificacao</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='id_classificacao']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:label=&quot;Classificacao:&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>0e6172d2-1fed-4a0e-aa5a-868f7119a810</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>classificacao</value>
      <webElementGuid>7cc28c5a-4e9a-4479-85a1-4b13baaa790f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>id_classificacao</value>
      <webElementGuid>8c7a9864-02a9-46b8-a052-1ab936aad634</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
  ---------

  10 (10+)

  14 (14+)

</value>
      <webElementGuid>e8e5447a-8dd7-4ef0-ad38-da9f2709fa2d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;id_classificacao&quot;)</value>
      <webElementGuid>ac043a85-e38d-455c-9761-b1bb1c770682</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='id_classificacao']</value>
      <webElementGuid>937008a5-de6d-4804-8067-946c0ffc5817</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Classificacao:'])[1]/following::select[1]</value>
      <webElementGuid>a81cf2f2-c291-496d-aac3-c59e93f220f3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Diretor:'])[1]/following::select[2]</value>
      <webElementGuid>d5b98ea6-debd-4c62-9cdf-1daabf094b45</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Trailer:'])[1]/preceding::select[1]</value>
      <webElementGuid>bd2d7afb-df80-45cb-9cf7-36eae0e51272</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Salvar'])[1]/preceding::select[1]</value>
      <webElementGuid>faffd9ec-7235-49da-bd75-7fa3e4f3885c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p[6]/select</value>
      <webElementGuid>b86251c1-11b8-4ce7-acaf-bf5ad2a102c9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@name = 'classificacao' and @id = 'id_classificacao' and (text() = '
  ---------

  10 (10+)

  14 (14+)

' or . = '
  ---------

  10 (10+)

  14 (14+)

')]</value>
      <webElementGuid>ca09ce08-1005-4b34-8322-15f650364c9d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
