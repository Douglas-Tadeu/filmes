<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Novo Filme</name>
   <tag></tag>
   <elementGuidId>43444a35-bcd9-42ae-a97e-1d754a16a38c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>main > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'Novo Filme')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Novo Filme&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>9716d546-a084-454f-9ba3-9aa8419624d6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/catalogo/filmes/novo/</value>
      <webElementGuid>4f3b3d49-9ee4-4640-927f-a5726d417a97</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Novo Filme</value>
      <webElementGuid>90eb1659-500a-46bb-8bcd-0f8e31359512</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/main[1]/a[1]</value>
      <webElementGuid>6cdaf7ef-86fc-4315-a6ca-cda0ebb54eee</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Novo Filme')]</value>
      <webElementGuid>76afa901-2ad0-403c-a636-b550988163cb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Filmes'])[1]/following::a[1]</value>
      <webElementGuid>c9eef838-412c-4cd4-ac7f-1e4380362c84</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Gerenciar Favoritos'])[1]/following::a[1]</value>
      <webElementGuid>4da1bc0a-9750-4177-b605-57ef17990909</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Editar'])[1]/preceding::a[1]</value>
      <webElementGuid>df021e9f-699f-4668-9c76-8c7fc86861d4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Novo Filme']/parent::*</value>
      <webElementGuid>333bb989-0ee0-4b7d-b2ac-538175730578</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/catalogo/filmes/novo/')]</value>
      <webElementGuid>42d891d9-a6a9-4d8e-bd07-b697732a93e6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//main/a</value>
      <webElementGuid>a46f819b-d0b8-4410-9746-21978642011e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/catalogo/filmes/novo/' and (text() = 'Novo Filme' or . = 'Novo Filme')]</value>
      <webElementGuid>e1c4077b-74d5-4643-a9b7-4aed7d6891e4</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
