<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Filmes</name>
   <tag></tag>
   <elementGuidId>ef71459a-dae6-4ca8-8458-bc540a77613d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a.btn-dashboard</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'🎞️ Filmes')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;🎞️ Filmes&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>91e3638a-fd8a-4349-bae4-5b788a851689</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/catalogo/filmes/</value>
      <webElementGuid>0cf07adc-2a1a-4e77-b012-18775b6e3004</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn-dashboard</value>
      <webElementGuid>527777eb-dda9-4979-8d85-62d1544a9a8d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>🎞️ Filmes</value>
      <webElementGuid>3379f62e-e4ad-4046-981c-da8577fe14c9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/main[1]/div[@class=&quot;grid grid-cols-2 md:grid-cols-3 gap-6 mt-6&quot;]/a[@class=&quot;btn-dashboard&quot;]</value>
      <webElementGuid>c59013e0-66af-4b16-9ba6-907cdf073a69</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'🎞️ Filmes')]</value>
      <webElementGuid>3d8b47e4-1d84-440f-8b10-7e4e1b891772</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Bem-vindo, Tadeu!'])[1]/following::a[1]</value>
      <webElementGuid>0a84b778-ea71-47ab-a31c-c5f6bfa12f8d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Gerenciar Favoritos'])[1]/following::a[1]</value>
      <webElementGuid>3c2ec936-2e6b-4aa8-b327-95d6b31ee61f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='🎬 Gêneros'])[1]/preceding::a[1]</value>
      <webElementGuid>3c2b87fb-e019-4580-8584-9fcd438a3654</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='🎬 Diretores'])[1]/preceding::a[2]</value>
      <webElementGuid>a4ee2b7c-1871-4331-bc7a-0e1f30e06034</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='🎞️ Filmes']/parent::*</value>
      <webElementGuid>a453da7c-7286-478e-8d19-166be5e59b18</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, '/catalogo/filmes/')])[2]</value>
      <webElementGuid>95dcf5be-884b-4610-923a-0f20e5a2b8bb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/a</value>
      <webElementGuid>ef45b5fa-f679-4f1e-b2c3-7198b25d91b8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/catalogo/filmes/' and (text() = '🎞️ Filmes' or . = '🎞️ Filmes')]</value>
      <webElementGuid>57775bfa-8cf8-47ec-886b-71b1704bd5e4</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
