<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>label_Idade minima</name>
   <tag></tag>
   <elementGuidId>acb088ef-1f47-45a5-9fd0-cd39c5d87696</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>p:nth-of-type(2) > label</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Descricao:'])[1]/following::label[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Idade minima:&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>label</value>
      <webElementGuid>91e25de9-510e-44f9-bddc-d727c2b67bd2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>for</name>
      <type>Main</type>
      <value>id_idade_minima</value>
      <webElementGuid>917bdf16-e054-4755-b378-bab8d583f8ba</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Idade minima:</value>
      <webElementGuid>b60d8d67-1990-45ae-9058-afc455037294</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/main[1]/form[1]/p[2]/label[1]</value>
      <webElementGuid>9fe200ff-c8ae-4e85-824f-d3105901d039</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Descricao:'])[1]/following::label[1]</value>
      <webElementGuid>6e639ae8-b923-41d8-8b28-f97de3e67007</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Adicionar Classificação'])[1]/following::label[2]</value>
      <webElementGuid>fc9a1b72-1b4d-41e6-8550-ed5e5cc3b938</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Salvar'])[1]/preceding::label[1]</value>
      <webElementGuid>e8a03f4b-6928-49d0-82be-fb0246140eae</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Voltar'])[1]/preceding::label[1]</value>
      <webElementGuid>05fa5763-9940-43ff-b2aa-a6b21acc8f9c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Idade minima:']/parent::*</value>
      <webElementGuid>b1e4ac59-75d4-4c2f-afe2-d42e6e1f91e5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p[2]/label</value>
      <webElementGuid>a089f6a3-c97f-46e0-b7a9-4004ad86de5d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//label[(text() = 'Idade minima:' or . = 'Idade minima:')]</value>
      <webElementGuid>dea5c06f-87a6-4527-9dc0-a71bd1afdaaf</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
