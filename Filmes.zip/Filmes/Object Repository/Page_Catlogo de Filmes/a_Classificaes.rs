<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Classificaes</name>
   <tag></tag>
   <elementGuidId>790db267-d1e6-46b5-9056-a60ff1b2efab</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'🏷️ Classificações')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;🏷️ Classificações&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>e7cf763a-ee2b-4877-9058-b3af8b8d78d8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/catalogo/classificacoes/</value>
      <webElementGuid>fa4a48e6-1769-4b29-97ce-57010ffaa101</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn-dashboard</value>
      <webElementGuid>0904fcd6-5d68-4da6-a8cd-5e6b0f53b5a9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>🏷️ Classificações</value>
      <webElementGuid>25b3f59e-8187-498d-a8cb-30377ea5d98b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/main[1]/div[@class=&quot;grid grid-cols-2 md:grid-cols-3 gap-6 mt-6&quot;]/a[@class=&quot;btn-dashboard&quot;]</value>
      <webElementGuid>89450bdc-53e3-4775-8f0e-28b489baad6e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'🏷️ Classificações')]</value>
      <webElementGuid>e0ceb769-2fe6-4ef5-8b0e-0fe0298cfac3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='🎥 Elenco'])[1]/following::a[1]</value>
      <webElementGuid>c097f439-bb2d-4057-9beb-790d89dad9de</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='🎭 Atores'])[1]/following::a[2]</value>
      <webElementGuid>c8847e52-adf0-488e-a586-6d354f718a3a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='📺 Trailers'])[1]/preceding::a[1]</value>
      <webElementGuid>0b7abb79-6f33-47fd-8e14-5ae3cd9ea21c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='⭐ Favoritos'])[1]/preceding::a[2]</value>
      <webElementGuid>63d7913b-3672-4cd2-adf2-20221a8bf9fe</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='🏷️ Classificações']/parent::*</value>
      <webElementGuid>aad60318-ba88-4b49-a6a3-266400244ecb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, '/catalogo/classificacoes/')])[2]</value>
      <webElementGuid>3a08a0eb-a3f3-4fb4-b595-6f15b57df030</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//a[6]</value>
      <webElementGuid>733bc7dc-844c-4bf9-bec2-39f6f2b68afc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/catalogo/classificacoes/' and (text() = '🏷️ Classificações' or . = '🏷️ Classificações')]</value>
      <webElementGuid>8b91286d-cd02-4a2a-851a-b01389f1e426</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
