<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_---------  Netflix</name>
   <tag></tag>
   <elementGuidId>c202401f-3023-4808-a41d-a422bfb9ce03</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#id_diretor</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='id_diretor']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:label=&quot;Diretor:&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>c0b7fee9-77d9-4b9f-8504-ef8240e40b98</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>diretor</value>
      <webElementGuid>fa0bbd1c-7908-4d93-a14c-137b99d8063a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>id_diretor</value>
      <webElementGuid>289f62d5-857d-41d1-a88d-449b7c114659</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
  ---------

  Netflix

</value>
      <webElementGuid>be8ce309-c871-40a7-8d8e-102915b94de2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;id_diretor&quot;)</value>
      <webElementGuid>a6a4539c-29ee-4a22-a201-f2a8a2ea5dde</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='id_diretor']</value>
      <webElementGuid>25a08cad-1758-42a0-80c7-d1d10e23c2b3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Diretor:'])[1]/following::select[1]</value>
      <webElementGuid>dc210f3f-ede3-4013-b035-aea270bc7b33</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Genero:'])[1]/following::select[2]</value>
      <webElementGuid>e745db52-ca44-4026-b3b5-c259ea87cc2f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Classificacao:'])[1]/preceding::select[1]</value>
      <webElementGuid>d5cefc95-4ade-4270-95fc-b5ce96d85540</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Trailer:'])[1]/preceding::select[2]</value>
      <webElementGuid>eff4ef93-a65a-4166-a4af-a03d398413cb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p[5]/select</value>
      <webElementGuid>38abacdd-f7e6-4574-b63f-934f01a36e00</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@name = 'diretor' and @id = 'id_diretor' and (text() = '
  ---------

  Netflix

' or . = '
  ---------

  Netflix

')]</value>
      <webElementGuid>56ce5b45-b2dd-4a8d-8ad3-8f85047d1426</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
