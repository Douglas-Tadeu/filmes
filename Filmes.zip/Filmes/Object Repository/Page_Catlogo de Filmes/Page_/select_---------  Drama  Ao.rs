<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_---------  Drama  Ao</name>
   <tag></tag>
   <elementGuidId>aa8e063e-a991-4794-9ba9-6b0f0b509f2a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#id_genero</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='id_genero']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:label=&quot;Genero:&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>022162b4-54a6-48c0-9de7-486f1a2b6f27</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>genero</value>
      <webElementGuid>78814f2c-b4fa-4183-9a00-e23b22d470a8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>id_genero</value>
      <webElementGuid>7209add5-2c70-40e1-83c6-9289522dac80</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
  ---------

  Drama

  Ação

</value>
      <webElementGuid>17dda813-b73e-4a3e-9ae1-fa37c7ed9b3e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;id_genero&quot;)</value>
      <webElementGuid>7f740ea0-9fb4-4a19-b851-51820ddf508c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='id_genero']</value>
      <webElementGuid>0e27c09f-4d42-4c7b-b947-1a859ef42c3d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Genero:'])[1]/following::select[1]</value>
      <webElementGuid>e6063930-2f01-49f9-9f5b-05a3473375fb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Ano:'])[1]/following::select[1]</value>
      <webElementGuid>0fea7b58-8add-478a-8eb2-90cce4c4ec17</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Diretor:'])[1]/preceding::select[1]</value>
      <webElementGuid>bd006c69-74bc-4a10-b7cf-a2fd9ebce4c1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Classificacao:'])[1]/preceding::select[2]</value>
      <webElementGuid>0f277983-7d39-4b14-a658-415096a619b6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//select</value>
      <webElementGuid>e2ba87bc-06f4-4e30-bbc8-e206f3d9e9ba</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@name = 'genero' and @id = 'id_genero' and (text() = '
  ---------

  Drama

  Ação

' or . = '
  ---------

  Drama

  Ação

')]</value>
      <webElementGuid>f2ecf098-5714-4315-bbdb-792ece7e80d1</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
