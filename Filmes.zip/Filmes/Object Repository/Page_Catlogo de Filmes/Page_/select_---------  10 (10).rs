<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_---------  10 (10)</name>
   <tag></tag>
   <elementGuidId>3b6eee1d-42ce-4bf6-9436-fd3d3a81dc6f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#id_classificacao</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='id_classificacao']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:label=&quot;Classificacao:&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>497df043-e5f6-49d9-92a1-a74ec670ccc3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>classificacao</value>
      <webElementGuid>828f43f7-9641-4ad6-bada-4250ae08e62b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>id_classificacao</value>
      <webElementGuid>da077383-8194-42c5-94b1-db8015ff47bd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
  ---------

  10 (10+)

</value>
      <webElementGuid>2a196df4-9af5-48e6-9a62-49440ec048c0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;id_classificacao&quot;)</value>
      <webElementGuid>ea73fbf0-f5d5-46dd-94c8-74fd7cc6f920</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='id_classificacao']</value>
      <webElementGuid>84ff0dee-c1bd-4c20-9c29-e93c0dc6dd80</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Classificacao:'])[1]/following::select[1]</value>
      <webElementGuid>5efc3612-3573-443b-be18-2713c0ce266e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Diretor:'])[1]/following::select[2]</value>
      <webElementGuid>cdf061af-4270-40e7-a4fa-2e3d9ef55976</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Trailer:'])[1]/preceding::select[1]</value>
      <webElementGuid>5ea6c7a9-460c-44cb-961a-91ed0ca362f7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Salvar'])[1]/preceding::select[1]</value>
      <webElementGuid>f4d9c0e2-38b4-4c40-a0a9-cc3ab37821d8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p[6]/select</value>
      <webElementGuid>517d17ad-e093-4e03-88bf-0da562f27fd6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@name = 'classificacao' and @id = 'id_classificacao' and (text() = '
  ---------

  10 (10+)

' or . = '
  ---------

  10 (10+)

')]</value>
      <webElementGuid>fdf98166-417e-4ddd-b175-03d0f14deb2a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
