<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Gneros</name>
   <tag></tag>
   <elementGuidId>256806cb-e5c2-4466-8edd-83bf9272bb86</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'🎬 Gêneros')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;🎬 Gêneros&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>9408f7df-76e5-4cf6-a429-5bf6d5e5ea0f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/catalogo/generos/</value>
      <webElementGuid>c5624719-be16-4a75-a51f-0268fca98626</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn-dashboard</value>
      <webElementGuid>bad49c20-5c22-41f1-b856-286a42210b58</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>🎬 Gêneros</value>
      <webElementGuid>95392c68-d361-43ab-b51e-da8ff46aa01e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/main[1]/div[@class=&quot;grid grid-cols-2 md:grid-cols-3 gap-6 mt-6&quot;]/a[@class=&quot;btn-dashboard&quot;]</value>
      <webElementGuid>4ca89d8d-c40b-4cf8-819e-3fea5d4e695f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'🎬 Gêneros')]</value>
      <webElementGuid>ba1983e5-7f73-4bcc-95d8-acb95cb217c7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='🎞️ Filmes'])[1]/following::a[1]</value>
      <webElementGuid>a01a6e28-f715-4219-8e46-7dce3bcf34d5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Bem-vindo, Silva!'])[1]/following::a[2]</value>
      <webElementGuid>c6e162e7-6003-434d-9839-8f944b0df309</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='🎬 Diretores'])[1]/preceding::a[1]</value>
      <webElementGuid>2ed90e99-1e9f-403c-bf35-c0a206f4476b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='🎭 Atores'])[1]/preceding::a[2]</value>
      <webElementGuid>cee1b89b-d8c9-4488-854f-ae4a217ed17a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='🎬 Gêneros']/parent::*</value>
      <webElementGuid>de61f111-226d-4efb-9b20-ad8492801dd0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, '/catalogo/generos/')])[2]</value>
      <webElementGuid>d502603a-32c1-4926-9316-5870af71dd26</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//a[2]</value>
      <webElementGuid>a8af3b76-a084-439c-a209-378a2a3a8d4f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/catalogo/generos/' and (text() = '🎬 Gêneros' or . = '🎬 Gêneros')]</value>
      <webElementGuid>f670b03e-b627-4d94-a993-f84b5015ab16</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
