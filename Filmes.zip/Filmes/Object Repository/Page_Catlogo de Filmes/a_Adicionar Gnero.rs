<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Adicionar Gnero</name>
   <tag></tag>
   <elementGuidId>5e64d153-7b0a-4db3-9d35-c9f9d05fc652</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>main > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'➕ Adicionar Gênero')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;➕ Adicionar Gênero&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>8422cd07-579d-4ceb-84e7-44e8342d841f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/catalogo/generos/criar/</value>
      <webElementGuid>687f1f02-29a6-4e3a-9a51-8c6d74d7c6f1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>➕ Adicionar Gênero</value>
      <webElementGuid>a2dfbaa5-f8a3-48eb-aae3-3db21168f47a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/main[1]/a[1]</value>
      <webElementGuid>fcba2c36-d18c-434c-ae26-8d94d41f35ed</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'➕ Adicionar Gênero')]</value>
      <webElementGuid>7293718a-4c4f-4ea2-8540-22d0b2b7eb93</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Gêneros'])[1]/following::a[1]</value>
      <webElementGuid>be830640-64ec-4779-9e1d-053dcd63740d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Gerenciar Favoritos'])[1]/following::a[1]</value>
      <webElementGuid>20fe75ce-5245-4ce9-a5f6-24e8925343ac</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Editar'])[1]/preceding::a[1]</value>
      <webElementGuid>295f05dd-23fd-481d-9d82-9c34acc42f0e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='➕ Adicionar Gênero']/parent::*</value>
      <webElementGuid>fac83da6-707f-4a14-834e-24cbe854cf35</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/catalogo/generos/criar/')]</value>
      <webElementGuid>32622433-385e-47ec-bfea-1f5720215517</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//main/a</value>
      <webElementGuid>683734c7-9c85-422c-b02e-11a0b0c1618d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/catalogo/generos/criar/' and (text() = '➕ Adicionar Gênero' or . = '➕ Adicionar Gênero')]</value>
      <webElementGuid>b7fe330f-9467-4d01-8d61-b45debb302d0</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
