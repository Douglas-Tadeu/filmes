<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Novo Ator</name>
   <tag></tag>
   <elementGuidId>53f3f63f-6464-4024-9374-669545a2629e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a.btn.btn-primary.mb-3</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'Novo Ator')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Novo Ator&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>638868ee-5a84-431c-a487-6255c3360977</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/catalogo/atores/novo/</value>
      <webElementGuid>794a32c8-5d44-4287-b60a-dc4a1c39bd18</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn btn-primary mb-3</value>
      <webElementGuid>35b64d0b-c6b9-4c4e-9baa-f5eea7653844</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Novo Ator</value>
      <webElementGuid>5e1b4ec2-b296-49d0-8b03-cf39dc864f3f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/main[1]/a[@class=&quot;btn btn-primary mb-3&quot;]</value>
      <webElementGuid>50d0c2c5-f137-400c-ac69-290771914bbe</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Novo Ator')]</value>
      <webElementGuid>44409ccc-7f98-4af5-b7c5-d28e528c95e2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Lista de Atores'])[1]/following::a[1]</value>
      <webElementGuid>fc842d00-ecdf-4b0c-acb9-421a529aadf0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Gerenciar Favoritos'])[1]/following::a[1]</value>
      <webElementGuid>af827440-4172-49da-a072-3594fb380114</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Nome'])[1]/preceding::a[1]</value>
      <webElementGuid>e9d29832-f5ab-433b-a334-fdad3823d014</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Data de Nascimento'])[1]/preceding::a[1]</value>
      <webElementGuid>29c87460-81b9-4542-972d-5c55e0ddc74e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Novo Ator']/parent::*</value>
      <webElementGuid>f32b7bbb-d048-4e5b-a5de-764729b2fc2f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/catalogo/atores/novo/')]</value>
      <webElementGuid>b593b148-20db-4df5-ae35-dc2fdc31373a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//main/a</value>
      <webElementGuid>bbce83f6-9575-4503-96c9-db5d6fa5eb57</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/catalogo/atores/novo/' and (text() = 'Novo Ator' or . = 'Novo Ator')]</value>
      <webElementGuid>93a680a0-f1f6-4e05-aabf-b4433b9e078d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
