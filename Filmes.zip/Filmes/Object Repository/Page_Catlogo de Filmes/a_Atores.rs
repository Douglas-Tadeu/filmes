<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Atores</name>
   <tag></tag>
   <elementGuidId>b1c20274-8ad5-422d-b932-3674254b8ad7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'🎭 Atores')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;🎭 Atores&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>9a5f9ef5-bf4d-458a-a8ff-1475f8ea9213</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/catalogo/atores/</value>
      <webElementGuid>bcfac762-87c4-4dfb-b58b-19ab8945e063</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn-dashboard</value>
      <webElementGuid>45a2f916-5f12-4d31-954c-f3664263ed5e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>🎭 Atores</value>
      <webElementGuid>0ded4be1-d05a-4f7b-a65e-a9131ccc920d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/main[1]/div[@class=&quot;grid grid-cols-2 md:grid-cols-3 gap-6 mt-6&quot;]/a[@class=&quot;btn-dashboard&quot;]</value>
      <webElementGuid>ddd72e00-c8c6-4196-aa9f-dd26f88764c9</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'🎭 Atores')]</value>
      <webElementGuid>2c84c2d5-c902-4382-8d52-af32be3e8ff4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='🎬 Diretores'])[1]/following::a[1]</value>
      <webElementGuid>51e6dd0d-e6bb-4c2e-bb54-6c99a1499f07</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='🎬 Gêneros'])[1]/following::a[2]</value>
      <webElementGuid>c3a4a2c8-5e2e-4d40-880b-e29a45fcefde</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='🎥 Elenco'])[1]/preceding::a[1]</value>
      <webElementGuid>6100674d-a210-4cb6-9d44-92daf8610eee</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='🏷️ Classificações'])[1]/preceding::a[2]</value>
      <webElementGuid>b9e8fef8-4fcd-43d9-aac2-707d5a459fef</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='🎭 Atores']/parent::*</value>
      <webElementGuid>a8a8e8b2-71ab-456f-8fee-86565264ff45</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, '/catalogo/atores/')])[2]</value>
      <webElementGuid>5a534e6b-8663-4267-b5bb-40e8f68fd950</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//a[4]</value>
      <webElementGuid>ac014017-64aa-45ec-8bef-5ecea1ae970a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/catalogo/atores/' and (text() = '🎭 Atores' or . = '🎭 Atores')]</value>
      <webElementGuid>86509376-1d9a-4f52-9889-0096658784e4</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
